class Shape(): # Parent Class
    def draw(self):
        pass

    def getArea(self):
        pass
